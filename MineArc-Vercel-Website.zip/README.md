# MineArc Vercel Website

A Vercel-ready static website based on the supplied MineArc store screenshot.

## Deploy on Vercel
1. Upload this folder to a GitHub repository.
2. Open Vercel and import the repository.
3. Framework preset: Other.
4. Leave Build Command and Output Directory empty.
5. Deploy.

Discord: https://discord.gg/8RU4DScGDz
